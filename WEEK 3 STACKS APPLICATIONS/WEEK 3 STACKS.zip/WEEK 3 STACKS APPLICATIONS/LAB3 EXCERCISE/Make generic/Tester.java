public class Tester
{
    public static void main()
    {
        StackInterface<Character> s = new LinkedStack<Character>();

        for (Character ch = 'A'; ch < 'F'; ++ch)
            s.push(ch);

        while (!s.isEmpty())
            System.out.println(s.pop());

        System.out.println("done");
    }
}
