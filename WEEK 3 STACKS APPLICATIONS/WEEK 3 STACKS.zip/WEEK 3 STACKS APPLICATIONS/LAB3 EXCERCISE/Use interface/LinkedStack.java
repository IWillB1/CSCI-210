public class LinkedStack implements StackInterface
{
    private Item top;

    public LinkedStack()
    {
        top = null;
    }

    public void push(int i)
    {
        Item item = new Item(i);
        
        if (!isEmpty())
            item.next = top;
            
        top = item;
    }
    
    public int pop()
    {
            int i = top.info;
            top = top.next;
            return i;
    }

    public boolean isEmpty()
    {
        return top == null;
    }

}
