import java.awt.Rectangle;

public class Orphan
{
    public Orphan()
    {
        Rectangle r1 = new Rectangle(10, 20);
        Rectangle r2 = new Rectangle(30, 40);
        
        r2 = r1;    // deliberately create an orphan object
    }
}