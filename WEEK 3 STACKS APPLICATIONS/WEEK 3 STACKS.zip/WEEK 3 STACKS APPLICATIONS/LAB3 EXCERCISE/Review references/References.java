import java.awt.Rectangle;

public class References
{
    public References()
    {
        Rectangle r1 = new Rectangle(10, 20);
        
        Rectangle r2 = r1;
        r2.setSize(30, 40);
        System.out.println(r1);
    }
}