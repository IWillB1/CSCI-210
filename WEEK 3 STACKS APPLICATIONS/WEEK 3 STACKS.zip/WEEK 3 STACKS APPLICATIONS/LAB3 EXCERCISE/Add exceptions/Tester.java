public class Tester
{
    public static void main()
    {
        StackInterface<Integer> s = new LinkedStack<Integer>();

        // deliberate underflow
        try {
            System.out.println(s.pop());
        }
        catch (StackUnderflowException underflow) {
            System.out.println("Exception: " + underflow.getMessage());
            System.err.println("Exception: " + underflow.getMessage());
            System.exit(1);
        }
        System.out.println("done");
    }
}
